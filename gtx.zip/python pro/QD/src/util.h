#include <string>

void append_expn(std::string &str, int expn);

